package org.example;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ExampleTest {

    @Test
    public void testHello(){
        assertEquals("Hello", new Example().hello());
    }

}