import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.example.Example;
import org.junit.jupiter.api.Assertions;

public class MyStepdefs {
    String hello;
    @Given("I have the application")
    public void iHaveTheApplication() {
    }

    @When("I call hello")
    public void iCallHello() {
        String hello = new Example().hello();
    }

    @Then("I get Hello")
    public void iGetHello() {
        Assertions.assertEquals("hello", "hello");
    }
}
