package org.example;

public class Example {
    public String hello(){
        return "Hello";
    }
}