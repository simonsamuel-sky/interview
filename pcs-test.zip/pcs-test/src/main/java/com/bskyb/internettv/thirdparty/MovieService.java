package com.bskyb.internettv.thirdparty;

public interface MovieService {
        String getParentalControlLevel(String movieId) throws TitleNotFoundException, TechnicalFailureException;
}
