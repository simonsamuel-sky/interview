from abc import abstractmethod


class MovieService:
    @abstractmethod
    def get_parental_control_level(self, movie_id: str) -> str:
        """
        :param movie_id: id of the movie
        :return: parental control level of the movie
            can be any of ["U", "PG", "12", "15", "18"]
        :raises: TitleNotFoundException, TechnicalFailureException
        """
        pass
