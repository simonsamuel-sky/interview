class TechnicalFailureException(Exception):
    pass
