class TitleNotFoundException(Exception):
    pass
